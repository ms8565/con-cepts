const addUser = (data) => {
  hash = data.hash;
  players[hash] = data;
};