

class Answer {
  constructor(author, text) {
    this.author = author;
    this.text = text;
    this.pickedBy = [];
  }
}


module.exports = Answer;
