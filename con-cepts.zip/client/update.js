const addUser = (data) => {
  //hash = data.player;
  //players[hash] = data;
};